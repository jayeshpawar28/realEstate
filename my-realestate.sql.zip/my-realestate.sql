-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2024 at 05:36 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my-realestate`
--

-- --------------------------------------------------------

--
-- Table structure for table `add-enq`
--

CREATE TABLE `add-enq` (
  `properties_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `enqueries_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mobile` varchar(200) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `requirement` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add-enq`
--

INSERT INTO `add-enq` (`properties_id`, `user_id`, `enqueries_id`, `name`, `email`, `mobile`, `subject`, `requirement`) VALUES
(3, 1, 1, 'deepak thakur', 'ram1213@gmail.com', '423232332234', 'ffsffdf', 'sdfdsdf'),
(3, 1, 2, 'deepak thakur', 'jay123@gmail.com', '423232332234', 'sfsdfdf', 'sfsdfsd'),
(3, 2, 3, 'deepak thakur singh', 'deepthakur@gmail.com', '7498598116', 'daer', 'ddeee'),
(0, 0, 4, 'sagar', 'ram1213@gmail.com', '3234223233', 'sanjana', 'fdfs'),
(0, 0, 5, 'mohan deshpande', 'mohan@gmail.com', '7498598116', 'properties', 'flat for sale'),
(7, 2, 6, 'deepak thakur', 'redtape@gmail.com', '9325035920', 'adsad', 'dadd'),
(8, 1, 7, 'jayesh pawvar', 'jay123@gmail.com', '3234223233', 'casadasd', 'adasd'),
(0, 2, 8, 'adam', 'adam@gmail.com', '3435453342', 'property', 'test'),
(0, 2, 9, 'adam', 'adam@gmail.com', '3435453342', 'property', 'test'),
(0, 2, 10, 'adam', 'adam@gmail.com', '3435453342', 'property', 'sell'),
(0, 2, 11, 'adam', 'adam@gmail.com', '3435453342', 'property', 'home flat'),
(6, 3, 12, 'jethalal gada', 'jetha@gmail.com', '7498598116', 'property', 'adsd'),
(8, 3, 13, 'jethalal gada', 'jetha@gmail.com', '7498598116', 'property', 'get'),
(8, 3, 14, 'jethalal gada', 'jetha@gmail.com', '7498598116', 'property', 'failed'),
(6, 2, 15, 'adam', 'adam@gmail.com', '3435453342', 'property', 'subje'),
(6, 2, 16, 'adam', 'adam@gmail.com', '3435453342', 'property', 'great'),
(6, 2, 17, 'adam', 'adam@gmail.com', '3435453342', 'property', 'game'),
(6, 2, 18, 'adam', 'adam@gmail.com', '3435453342', 'property', 'dsfdsd'),
(6, 4, 19, 'john', 'john12@gmail.com', '3435453342', 'sanjana', 'sfsf');

-- --------------------------------------------------------

--
-- Table structure for table `add-users`
--

CREATE TABLE `add-users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `mobile` varchar(200) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `requirement` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add-users`
--

INSERT INTO `add-users` (`user_id`, `user_name`, `email`, `password`, `mobile`, `subject`, `requirement`) VALUES
(2, 'adam', 'adam@gmail.com', '3e7b522b9756d2578d3a86d8f366be6e', '3435453342', 'property', 'home flat'),
(3, 'jethalal gada', 'jetha@gmail.com', '3b29ba53c507b00a745ca7e2cbfd6acf', '7498598116', 'property', 'row-house'),
(4, 'john', 'john12@gmail.com', '3b29ba53c507b00a745ca7e2cbfd6acf', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `broker_tbl`
--

CREATE TABLE `broker_tbl` (
  `broker_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `short_desc` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `join_date` date NOT NULL,
  `broker_photo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `broker_tbl`
--

INSERT INTO `broker_tbl` (`broker_id`, `name`, `email`, `mobile`, `short_desc`, `address`, `join_date`, `broker_photo`) VALUES
(1, 'deepak', 'deepthakur@gmail.com', '3435453342', 'ddad', 'dada', '2023-10-17', '1697559223_19ae0a62ec2d1891fa21.jpg'),
(2, 'deepak', 'deepthakur@gmail.com', '3435453342', 'xvxcv', 'xcvxv', '2023-10-23', '1698057505_c4cb5138834d9f3ff5b8.webp'),
(3, 'jayesh', 'jay123@gmail.com', '7498598116', 'asasa', 'asasa', '2023-10-24', '1698138587_a4ef0517652b5f6b873d.webp'),
(4, 'RAM', 'ram1213@gmail.com', '7498598116', 'sdsd', 'sds', '2023-10-24', '1698138706_d2ca1a2c18f5e94dedcc.webp'),
(5, 'Rishikesh', 'rishi@gmail.com', '3435453342', 'sdssds', 'sd', '2023-10-29', '1698138767_90b96da845377b4db707.webp');

-- --------------------------------------------------------

--
-- Table structure for table `contact_tbl`
--

CREATE TABLE `contact_tbl` (
  `contact_id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mobile` varchar(200) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_tbl`
--

INSERT INTO `contact_tbl` (`contact_id`, `name`, `email`, `mobile`, `subject`, `message`) VALUES
(1, 'deepak thakur singh', 'jay123@gmail.com', '3435453342', 'adadad', 'adadds'),
(2, 'sanju', 'ammu11113@gmail.com', '3435453342', 'sanjana', 'dasdadsd'),
(3, 'deepak thakur', 'deepthakur@gmail.com', '3435453342', 'sanjana', 'dadad'),
(4, 'ram', 'ram1213@gmail.com', '3435453342', 'sanjana', 'dadsddad'),
(5, 'deepak thakur', 'jay123@gmail.com', '3435453342', 'sanjana', 'saaasss'),
(6, 'deepak thakur', 'deep@gmail.com', '3435453342', 'deee', 'asasa'),
(11, 'deepak thakur singh', 'deep@gmail.com', '423232332234', 'deee', 'sasasas'),
(12, 'deepak thakur', 'deepthakur@gmail.com', '3435453342', 'sanjana', 'ssasa'),
(14, 'deepak thakur singh', 'deep@gmail.com', '9325035920', 'deee', 'gfhfd'),
(18, 'deepak thakur', 'deep@gmail.com', '7498598116', 'properties', 'dada'),
(19, 'jayesh pawvar', 'deepthakur@gmail.com', '3435453342', 'sanjana', 'GXGG'),
(20, 'deepak thakur', 'deepthakur@gmail.com', '3435453342', 'adsd', 'sdsd');

-- --------------------------------------------------------

--
-- Table structure for table `login_tbl`
--

CREATE TABLE `login_tbl` (
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `photo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_tbl`
--

INSERT INTO `login_tbl` (`name`, `email`, `password`, `photo`) VALUES
('deepak thakur', 'deepthakur@gmail.com', 'fsss', '1697539406_5333d3fd88be30f9a404.webp'),
('deepak', 'deep@gmail.com', '7097c422d46bb61fc4c169dbbae1c1e6', ''),
('Jayesh Pawar', 'jay123@gmail.com', 'e9b3b3c8d7c5490ce2b3f41d1518c126', ''),
('john', 'john123@gmail.com', '6e0b7076126a29d5dfcbd54835387b7b', '');

-- --------------------------------------------------------

--
-- Table structure for table `properties_tbl`
--

CREATE TABLE `properties_tbl` (
  `broker_id` int(11) NOT NULL,
  `properties_id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `sqft` varchar(200) NOT NULL,
  `price` varchar(200) NOT NULL,
  `short_desc` varchar(200) NOT NULL,
  `type` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `state` varchar(200) NOT NULL,
  `city` mediumtext NOT NULL,
  `zipcode` varchar(20) NOT NULL,
  `bedroom` varchar(30) NOT NULL,
  `bathroom` varchar(30) NOT NULL,
  `garage` varchar(30) NOT NULL,
  `plot_size` varchar(200) NOT NULL,
  `main_photo` varchar(200) NOT NULL,
  `photo_1` varchar(200) NOT NULL,
  `photo_2` varchar(200) NOT NULL,
  `photo_3` varchar(100) NOT NULL,
  `photo_4` varchar(200) NOT NULL,
  `active` varchar(200) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `properties_tbl`
--

INSERT INTO `properties_tbl` (`broker_id`, `properties_id`, `title`, `sqft`, `price`, `short_desc`, `type`, `address`, `state`, `city`, `zipcode`, `bedroom`, `bathroom`, `garage`, `plot_size`, `main_photo`, `photo_1`, `photo_2`, `photo_3`, `photo_4`, `active`, `date`) VALUES
(1, 6, '1 BHK FLAT', '23', '$334', '', 'rent', 'AS', 'delhi', 'nashik', '422333', '1', '2', '1', '2332', '1698121696_c92273a3fa4e06f7228c.avif', '1698121696_c92273a3fa4e06f7228c.avif', '1698121696_698ee717e359cd0a1224.avif', '1698121696_53b388baff6aca89ecd9.avif', '1698121696_88908f6f8b8c5b08cb57.avif', 'yes', '2023-10-26 18:30:00'),
(3, 7, '2BHK FLAT', '1212', '$334', '', 'sale', 'DDSD', 'rajasthan', 'nashik', '422333', '3', '3', '2', '2332', '1698138659_025196937bebd02c6c15.jpeg', '1698138659_025196937bebd02c6c15.jpeg', '1698138659_025196937bebd02c6c15.jpeg', '1698138659_025196937bebd02c6c15.jpeg', '1698138659_025196937bebd02c6c15.jpeg', 'no', '2023-10-23 18:30:00'),
(4, 8, '2BHK ROW HOUSE', '1212', '$334', '', 'rent', 'DAD', 'maharashtra', 'nashik', '422333', '1', '2', '1', '2332', '1698138832_1bf113ffe37e46c16b8d.jpeg', '1698138832_1bf113ffe37e46c16b8d.jpeg', '1698138832_1bf113ffe37e46c16b8d.jpeg', '1698138832_1bf113ffe37e46c16b8d.jpeg', '1698138832_1bf113ffe37e46c16b8d.jpeg', 'yes', '2023-10-23 18:30:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add-enq`
--
ALTER TABLE `add-enq`
  ADD PRIMARY KEY (`enqueries_id`);

--
-- Indexes for table `add-users`
--
ALTER TABLE `add-users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `broker_tbl`
--
ALTER TABLE `broker_tbl`
  ADD PRIMARY KEY (`broker_id`);

--
-- Indexes for table `contact_tbl`
--
ALTER TABLE `contact_tbl`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `properties_tbl`
--
ALTER TABLE `properties_tbl`
  ADD PRIMARY KEY (`properties_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add-enq`
--
ALTER TABLE `add-enq`
  MODIFY `enqueries_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `add-users`
--
ALTER TABLE `add-users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `broker_tbl`
--
ALTER TABLE `broker_tbl`
  MODIFY `broker_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contact_tbl`
--
ALTER TABLE `contact_tbl`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `properties_tbl`
--
ALTER TABLE `properties_tbl`
  MODIFY `properties_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
